<?php
/**
 * Plugin Name: Syryus Backup Helper (Streaming Edition)
 * Description: Creates a database backup in pure PHP and streams it directly, without writing to the server filesystem.
 * Version: 2.0
 * Author: Syryus Assistant
 */

if (!defined('ABSPATH')) { exit; }

add_action('init', 'syryus_handle_backup_request_streaming');
function syryus_handle_backup_request_streaming() {
    if (isset($_GET['syryus_action']) && $_GET['syryus_action'] === 'backup_db' && isset($_GET['api_key'])) {
        $saved_api_key = get_option('syryus_api_key');
        if (!$saved_api_key || $_GET['api_key'] !== $saved_api_key) {
            wp_die('Invalid API Key.');
        }
        global $wpdb;
        $db_name = DB_NAME;
        $backup_file_name = 'db_' . preg_replace('/[^a-zA-Z0-9_.]/', '_', $db_name) . '_' . time() . '.sql';
        header('Content-Type: application/octet-stream');
        header('Content-Transfer-Encoding: Binary');
        header('Content-Disposition: attachment; filename="' . $backup_file_name . '"');
        $tables = $wpdb->get_results('SHOW TABLES', ARRAY_N);
        if (!$tables) { exit; }
        echo "-- Syryus Pure PHP DB Dump\n";
        echo "-- Host: " . DB_HOST . "\n";
        echo "-- Database: " . DB_NAME . "\n";
        echo "-- Generation Time: " . date('Y-m-d H:i:s') . "\n";
        echo "SET SQL_MODE = \"NO_AUTO_VALUE_ON_ZERO\";\n\n";
        foreach ($tables as $table_row) {
            $table = $table_row[0];
            $create_table = $wpdb->get_row("SHOW CREATE TABLE `{$table}`", ARRAY_N);
            echo "\n\n--\n-- Table structure for table `{$table}`\n--\n\n";
            echo $create_table[1] . ";\n\n";
            $data = $wpdb->get_results("SELECT * FROM `{$table}`", ARRAY_A);
            if ($data) {
                echo "--\n-- Dumping data for table `{$table}`\n--\n\n";
                foreach ($data as $row) {
                    $keys = implode('`, `', array_keys($row));
                    $values = [];
                    foreach ($row as $value) {
                        if (is_null($value)) {
                            $values[] = 'NULL';
                        } else {
                            $values[] = "'" . $wpdb->_real_escape($value) . "'";
                        }
                    }
                    echo "INSERT INTO `{$table}` (`{$keys}`) VALUES (" . implode(', ', $values) . ");\n";
                }
            }
        }
        exit;
    }
}

add_action('admin_menu', 'syryus_create_admin_menu');
function syryus_create_admin_menu() {
    add_options_page('Syryus Helper Settings', 'Syryus Helper', 'manage_options', 'syryus-helper', 'syryus_render_settings_page');
}
function syryus_render_settings_page() {
    if (isset($_POST['syryus_regenerate_key']) && check_admin_referer('syryus_regenerate_nonce')) {
        syryus_generate_and_save_key();
        echo '<div class="notice notice-success is-dismissible"><p>Új API kulcs sikeresen generálva!</p></div>';
    }
    $api_key = get_option('syryus_api_key');
    if (empty($api_key)) {
        $api_key = syryus_generate_and_save_key();
    }
    ?>
    <div class="wrap">
        <h1>Syryus Backup Helper Beállítások</h1>
        <p>Ez a bővítmény egy biztonságos végpontot biztosít a Syryus Backup alkalmazás számára az adatbázis-mentések készítéséhez.</p>
        <h2 style="margin-top: 30px;">API Kulcs</h2>
        <p>Másold ki ezt az automatikusan generált API kulcsot, és illeszd be a Syryus alkalmazásodban a megfelelő projekt "Helper API Kulcs" mezőjébe.</p>
        <input type="text" readonly="readonly" value="<?php echo esc_attr($api_key); ?>" id="syryus_api_key_field" style="width: 100%; max-width: 500px; padding: 5px; background: #f0f0f0;" onclick="this.select();">
        <button class="button" onclick="navigator.clipboard.writeText(document.getElementById('syryus_api_key_field').value); alert('Kulcs vágólapra másolva!');">Másolás</button>
        <form method="post" action="" style="margin-top: 20px;">
            <?php wp_nonce_field('syryus_regenerate_nonce'); ?>
            <input type="hidden" name="syryus_regenerate_key" value="1">
            <?php submit_button('Új API Kulcs Generálása'); ?>
        </form>
    </div>
    <?php
}
function syryus_generate_and_save_key() {
    $new_key = bin2hex(random_bytes(32));
    update_option('syryus_api_key', $new_key);
    return $new_key;
}
